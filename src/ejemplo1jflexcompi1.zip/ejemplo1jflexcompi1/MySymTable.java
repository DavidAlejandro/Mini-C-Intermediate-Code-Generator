/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplo1jflexcompi1;

import java.util.ArrayList;
import java.util.Collections;

/**
 *
 * @author David
 */
public class MySymTable {
   
    public ArrayList<SymTableRow> symtable = new ArrayList<SymTableRow>();
    public int for_count = 0;
    public int if_count = 0;
    public int while_count = 0;
    public int option_count = 0;
    public int select_count = 0;
    public int direccion = 0;
    
    // private node myAst;
    public boolean uniqueness = true;
    public boolean validTable = true;
  
     
     public MySymTable()
     {
         //this.symtable = null;
     }

    public void setScopes(int prof, node myAst)
    {
       
      // if(!myAst.children.isEmpty()){   
         
         for (int i = 0; i < myAst.children.size() ; i++)
         {
             
             myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
            
                  //System.out.println( myAst.children.get(i).sym); 
    
             //System.out.println(myAst.children.get(i).nodeScope);  
              
             if (myAst.children.get(i).sym == "ritual") 
             {
                //myAst.children.get(i).param_scope = "Vodoo";
                 //myAst.nodeScope = "Voodoo";
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                //System.out.println(myAst.children.get(i).nodeScope);        
             }
             if (myAst.children.get(i).sym == "spell") 
             {
                 //myAst.children.get(i).param_scope = myAst.children.get(1).sym;
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                 //System.out.println(myAst.children.get(i).nodeScope);
             }
             if (myAst.children.get(i).sym == "bloque") 
             {
                 if (myAst.sym == "spell") 
                 {
                      myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.children.get(1).sym;
                     // System.out.println(myAst.children.get(i).nodeScope);
                     
                 }
                 else
                 {
                      myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                      //System.out.println(myAst.children.get(i).nodeScope);
                 }
                
             }
             if (myAst.children.get(i).sym == "spellParams") 
             {
                 if (myAst.sym == "spell") 
                 {
                    // myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.children.get(1).sym;
                      myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.children.get(1).sym;
                     //System.out.println( myAst.children.get(i).nodeScope);
                 }
                 else
                 {
                     myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                     //System.out.println( myAst.children.get(i).nodeScope);
                 }
                
             }
             if (myAst.children.get(i).sym == "for") 
             {
                 myAst.children.get(i).sym = "for_" + for_count;
                 for_count++;
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                // System.out.println(myAst.children.get(i).nodeScope);        
             }
             if (myAst.children.get(i).sym == "if") 
             {
                 myAst.children.get(i).sym = "if_" + if_count;
                 if_count++;
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                 //System.out.println(myAst.children.get(i).nodeScope);        
             }
             if (myAst.children.get(i).sym == "while") 
             {
                 myAst.children.get(i).sym = "while_" + while_count;
                 while_count++;
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                 //System.out.println(myAst.children.get(i).nodeScope);        
             }
             if (myAst.children.get(i).sym == "opción") 
             {
                 myAst.children.get(i).sym = "opcion_" + option_count;
                 option_count++;
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                 //System.out.println(myAst.children.get(i).nodeScope);        
             }
             if (myAst.children.get(i).sym == "select") 
             {
                 myAst.children.get(i).sym = "select_" + select_count;
                 select_count++;
                 myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                // System.out.println(myAst.children.get(i).nodeScope);        
             }
             if (myAst.children.get(i).sym == "forParams") 
             {
                myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                 //System.out.println(myAst.children.get(i).sym);
             }
             if (myAst.children.get(i).sym == "param") 
             {
                myAst.children.get(i).nodeScope = myAst.nodeScope + "." + myAst.sym;
                //System.out.println(myAst.children.get(i).sym);
             }
             if (myAst.children.get(i).sym == "declaracion") 
             {
                     if (myAst.reversed == false)
                     {
                         //System.out.println(myAst.children.get(i).children.get(1).sym);
                         Collections.reverse(myAst.children);
                        // System.out.println(myAst.children.get(i).children.get(1).sym);
                     }
                     
                     myAst.reversed = true;
                     myAst.children.get(i).nodeScope = myAst.nodeScope ;
                     //myAst.children.get(i).nodeScope.replace(".declaraciones", "");
                    // System.out.println(myAst.children.get(i).nodeScope);    
                 
                   
             }
             myAst.children.get(i).nodeScope = myAst.children.get(i).nodeScope.replace(".bloque", "");
                
             if (!myAst.children.get(i).children.isEmpty()) 
             {
                            //child.writeTree(prof+=1);

                     setScopes(prof+=1, myAst.children.get(i));
                     prof-=1;
             }
            
         }
         
      // }//endif 
    }
    
    public void generateSymTable(int prof, node myAst)
    {
        //System.out.println(prof);
        //System.out.println(myAst.children.size());
      
        
        for (int i = 0; i < myAst.children.size() ; i++) {
        //for(node child: myAst.children){
                uniqueness = true;
    		SymTableRow row = new SymTableRow();
                 
               //if para que no haga las comparaciones de unicidad en donde no sea una decalración pero si hayan identificadores de variables.
               if ((myAst.sym.equals("=="))||(myAst.sym.contains("<"))||(myAst.sym.contains(">"))||(myAst.sym.contains("+"))||(myAst.sym.contains("-"))||(myAst.sym.contains("*"))||(myAst.sym.contains("/"))||(myAst.sym.contains("="))) 
               {}
               else{
               //if(!myAst.children.isEmpty()){
                if ((myAst.children.get(i).type != null)||(myAst.children.get(i).returnType != null)||(myAst.children.get(i).sym == "param")||(myAst.children.get(i).sym == "forParams")) 
                  {
                     
 
                      
                    if (myAst.children.get(i).returnType != null && myAst.children.get(i).sym == "spell") 
                    {
                        for (int j = 0; j < symtable.size(); j++) 
                        {
                            //Comprueba que la función no haya sido declarada anteriormente.
                            if ((myAst.children.get(i).children.get(1).sym.equals(symtable.get(j).id))&&(symtable.get(j).isFuncion() == true))
                            {
                                validTable = false;
                                System.out.println("Error semántico en la línea: " + myAst.children.get(i).children.get(1).lin +
                                        " Función " + myAst.children.get(i).children.get(1).sym + " ya ha sido declarada.");
                            }
                            else
                            {
                                row.setId(myAst.children.get(i).children.get(1).sym);
                                row.setFuncion(true);
                                ArrayList<String> exp_tipo = new ArrayList<String>();
                                exp_tipo.add(myAst.children.get(i).returnType);
                                if (myAst.children.get(i).params != null) 
                                {
                                for (int k = 0; k < myAst.children.get(i).params.children.size(); k++) 
                                {
                                   exp_tipo.add(myAst.children.get(i).params.children.get(k).children.get(0).sym);
                                }
                        }
                        
                        


                      row.setTipo_funcion(exp_tipo);
                            }
                        }
                        

                     }
                    else 
                    { 
                            if (myAst.children.get(i).sym == "param") 
                            {
                                //row.setAmbito(myAst.param_scope);
                                row.setAmbito(myAst.children.get(i).nodeScope);
                                row.setId(myAst.children.get(i).children.get(1).sym);
                                row.setTipo(myAst.children.get(i).children.get(0).sym);
                                row.setParam(true);
                            }
                            else
                            {
                                if (myAst.children.get(i).sym == "forParams") 
                                {
                                    row.setAmbito(myAst.children.get(i).nodeScope);
                                    row.setId(myAst.children.get(i).children.get(1).sym);
                                    row.setTipo(myAst.children.get(i).children.get(0).sym);
                                    //row.setParam(true);
                                }
                                else
                                {
                                    
                                    //para declaraciones.
                                    
                                    //Comprobación de unicidad.
                                        for (int j = 0; j < symtable.size(); j++) 
                                        {
                                            
                                            //System.out.println(myAst.children.get(i).sym);
                                            if((symtable.get(j).id.equals(myAst.children.get(i).children.get(1).sym))&&(symtable.get(j).ambito.equals(myAst.children.get(i).nodeScope))&&(symtable.get(j).isFuncion() != true))
                                            {   
                                                validTable = false;
                                                System.out.println("Error semántico en la línea: " + myAst.children.get(i).children.get(1).lin + " Columna: " 
                                                        + myAst.children.get(i).children.get(1).col + ", Variable " + myAst.children.get(i).children.get(1).sym +
                                                        " ya ha sido declarada.");
                                                uniqueness = false;
                                            }
                                            else if ((symtable.get(j).id.equals(myAst.children.get(i).children.get(1).sym))&&(myAst.children.get(i).nodeScope.contains(symtable.get(j).ambito))&&(symtable.get(j).isFuncion() != true))
                                            {
                                                validTable = false;
                                                System.out.println("Error semántico en la línea: " + myAst.children.get(i).children.get(1).lin + " Columna: " 
                                                        + myAst.children.get(i).children.get(1).col + ", Variable " + myAst.children.get(i).children.get(1).sym +
                                                        " ya ha sido declarada.");
                                                uniqueness = false;
                                            }
                                            
                                            //System.out.println(myAst.children.get(i).sym + ": " + myAst.children.get(i).type);
                                            //System.out.println(myAst.children.get(i).children.get(2).sym + ": " + myAst.children.get(i).children.get(2).type);
                                            
     
                                        }
                                        
                                        if (uniqueness == true)
                                        {
                                             row.setAmbito(myAst.children.get(i).nodeScope);
                                             row.setTipo(myAst.children.get(i).type);
                                             row.setId(myAst.children.get(i).children.get(1).sym);
                                            if (!myAst.children.get(i).nodeScope.contains("spell")) 
                                            {
                                                row.setDir(direccion);
                                                direccion = direccion + myAst.children.get(i).children.get(0).tamaño;

                                            }
                                        }
                                        
                                    
                                }
                                
                            }
                                
                    }

               // row.setParam(true);

                 //row.setTipo(myAst.children.get(i).returnType);
                    //System.out.println("|_"+child.sym);
                    if((row.ambito != "global"))
                    {
                        if (row.ambito.contains(".spellParams")) 
                        {
                            row.ambito = row.ambito.replace(".spellParams", "");
                        }
                         symtable.add(row);
                    }
                      if (row.isFuncion()) 
                      {
                          row.ambito = "null.startvoodoo";
                          symtable.add(row);
                      }
                   

                   
                }
             //  }   //endif
        }
                 if (!myAst.children.get(i).children.isEmpty()) {
                            //child.writeTree(prof+=1);

                         generateSymTable(prof+=1, myAst.children.get(i));
                         prof-=1;
                    }
           //row.setAmbito(null);
           // row.setDir(null);
            //row.setFuncion(true);
                
             
    	}    
    }
    
    public void printTable()
    {
       // System.out.println("");
        for (int i = 0; i < symtable.size(); i++) {
            
            symtable.get(i).printRow();
            System.out.println("\n");
            
        }
    }
}
