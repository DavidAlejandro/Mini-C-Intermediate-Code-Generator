/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplo1jflexcompi1;

import java.util.ArrayList;

/**
 *
 * @author David
 */
public class CuadrupleGenerator {
    
    public node myAst;
    public MySymTable mySymTable;
    public TypeCheck typeCheck;
    public sintactico sin ;
    public ArrayList<Cuadruple> symtable = new ArrayList<Cuadruple>();

    public CuadrupleGenerator(node myAst, MySymTable mySymTable, TypeCheck typeCheck, sintactico sin) {
        this.myAst = myAst;
        this.mySymTable = mySymTable;
        this.typeCheck = typeCheck;
        this.sin = sin;
    }
    
    
    public void generateCuadruples()
    {
        //Entra cuando no existen errors de ningún tipo en el código.
        if ((mySymTable.validTable == true)&&(typeCheck.validType == true)&&(sin.validSintax == true)) 
        {
            System.out.println("Generando....");
        }
    }
    
    
    
}
