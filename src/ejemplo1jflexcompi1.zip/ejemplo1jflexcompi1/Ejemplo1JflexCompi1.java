/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplo1jflexcompi1;

import java.io.File;
import java.io.FileInputStream;

import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.text.html.HTMLEditorKit.Parser;
/**
 *
 * @author david
 */
public class Ejemplo1JflexCompi1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws Exception {
        // TODO code application logic here
       System.out.println("-------------------------------");
    // new sintactico(new gramatilex(new FileInputStream("loop_test.txt"))).parse();
     
      //CUP$sintactico$actions  sintacticofresa;
      
       /*sintacticofresa = new sintactico(new gramatilex(new FileInputStream("loop_test.txt"))).action_obj;
       sintacticofresa.parse();
     System.out.println(sintacticofresa.getNodofresa());*/
       
      sintactico sin = new sintactico(new gramatilex(new FileInputStream("symtable_test.txt")));
        sin.parse();
        node nodo = sin.padre;
        nodo.removeFirst();
        MySymTable mst = new MySymTable();
         
        mst.setScopes(0, nodo);
        mst.generateSymTable(0, nodo);
        
        TypeCheck tc = new TypeCheck(mst);
        tc.startCheck(0, nodo);
        tc.typeCheck(0, nodo);
        
        CuadrupleGenerator cg = new CuadrupleGenerator(nodo, mst, tc, sin);
        cg.generateCuadruples();
        //mst.printTable();    
        nodo.display(0);
    
    
        
     //Para generar el lexer.
       
 // String path = "/Users/David/NetBeansProjects/Ejemplo1JflexCompi1/src/ejemplo1jflexcompi1/scanner.jflex";
 // generarLexer(path);
        
     //Para generar el parser.
        
   /*String path = "/Users/David/NetBeansProjects/Ejemplo1JflexCompi1/src/ejemplo1jflexcompi1/parser.cup";
         String opciones[] = new String[7];
        
        opciones[0] = "-destdir";
        opciones[1] = "/Users/David/NetBeansProjects/Ejemplo1JflexCompi1/src/ejemplo1jflexcompi1";
        opciones[2] = "-parser";
        opciones[3] = "sintactico";
        opciones[4] = "-symbols";
        opciones[5] = "simbolo";
        opciones[6] = "/Users/David/NetBeansProjects/Ejemplo1JflexCompi1/src/ejemplo1jflexcompi1/parser.cup";
        generarParser(opciones);
        */
    }
    
    public static void generarLexer(String path){
        File file=new File(path);
        JFlex.Main.generate(file);
    }
    
    public static void generarParser(String[] path)
    {
         
        try {
            //File file = new File(path);
            // jflex.Main.generate(file);
            java_cup.Main.main(path);
        } catch (IOException ex) {
            Logger.getLogger(Parser.class.getName()).log(Level.SEVERE, null, ex);
        } catch (Exception ex) {
            Logger.getLogger(Parser.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
