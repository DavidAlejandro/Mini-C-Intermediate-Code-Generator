/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package ejemplo1jflexcompi1;

/**
 *
 * @author David
 */
public class Cuadruple {
    public String operador;
    public String arg1;
    public String arg2;
    public String res;

    public Cuadruple(String operador, String arg1, String arg2, String res) {
        this.operador = operador;
        this.arg1 = arg1;
        this.arg2 = arg2;
        this.res = res;
    }
    
    
    
}
